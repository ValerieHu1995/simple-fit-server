package com.zju.cst.simplefitserver.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleFitServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SimpleFitServerApplication.class, args);
    }
}
